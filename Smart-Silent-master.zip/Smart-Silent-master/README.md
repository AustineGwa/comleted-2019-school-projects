# Smart-Silent

•	Automatically goes to silent mode & change into normal mode in prescribed time

•	Show current place to select that place from Google map

•	Can select a location & give a range so that when mobile will be on that range, phone will be silent automatically

•	Can select remote location

•	When one goes into prayer room, mobile will be silent automatically & when he goes outside of the prayer room , mobile will be set to normal mode

•	Silent rule can be set based on time or location
