package com.gwazasoftwares.fisda.interfaces;

import android.view.View;

public interface OnHomeItemClickListener {
    void onHomeItemClick(View view, int position);
}
