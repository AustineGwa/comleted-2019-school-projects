package com.gwazasoftwares.fisda;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.Window;
import android.view.WindowManager;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.gwazasoftwares.fisda.models.Church;
import com.gwazasoftwares.fisda.models.ChurchMember;
import com.gwazasoftwares.fisda.models.Contribution;
import com.gwazasoftwares.fisda.models.Department;
import com.gwazasoftwares.fisda.models.Group;
import com.gwazasoftwares.fisda.models.User;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;

public class Splash extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        this.requestWindowFeature(Window.FEATURE_NO_TITLE);
        this.getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);

        setContentView(R.layout.activity_splash);

        // Write a message to the database
        FirebaseDatabase database = FirebaseDatabase.getInstance();
        DatabaseReference myRef = database.getReference();

        Church church = new Church("Omindi","omindi@gmail.com",
                Arrays.asList(new Group("nyalunya","jo kowigo")),
                        Arrays.asList(new Department("AMO","married adventist men")),
                Arrays.asList(new ChurchMember("Austine","gwaza@gmail.com","youth","nyalunya",new Contribution("camp","200",150))));

        HashMap<String, Church> churchHashMap = new HashMap<>();
        churchHashMap.put("firstChurch", church);

        User user = new User("AustineGwa","austinegwa64@gmail.com","standard");
        List<User> allusers = new ArrayList<>();
        allusers.addAll(Arrays.asList(user));
        myRef.child("profiles").setValue(user);

        Thread thread  = new Thread(){

            @Override
            public  void run(){
                try {
                    Thread.sleep(3000);
//                        startHome();
                    startLogin();
                    finish();
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        };
        thread.start();
    }

    @Override
    protected void onStart() {
        super.onStart();

    }
    private void startLogin() {
        Intent i = new Intent(this, Login.class);
        startActivity(i);
    }

    private void startHome() {
        Intent i = new Intent(this, Home.class);
        startActivity(i);
    }
}
