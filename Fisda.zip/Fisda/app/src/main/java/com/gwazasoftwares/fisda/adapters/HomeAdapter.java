package com.gwazasoftwares.fisda.adapters;

import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.gwazasoftwares.fisda.R;
import com.gwazasoftwares.fisda.interfaces.OnHomeItemClickListener;
import com.gwazasoftwares.fisda.models.ChurchService;

import java.util.List;
import java.util.zip.Inflater;

public class HomeAdapter extends RecyclerView.Adapter<HomeAdapter.HomeViewHolder> {

    List<ChurchService> services;
    OnHomeItemClickListener listener;

    public HomeAdapter(List<ChurchService> services, OnHomeItemClickListener listener) {
        this.services = services;
        this.listener = listener;
    }

    @NonNull
    @Override
    public HomeViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {

        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.home_row, viewGroup,false);
        HomeViewHolder homeViewHolder = new HomeViewHolder(view, listener);
        return homeViewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull HomeViewHolder homeViewHolder, int i) {
        homeViewHolder.serviceImage.setImageResource(services.get(i).getHolderImage());
        homeViewHolder.serviceName.setText(services.get(i).getName());

    }

    @Override
    public int getItemCount() {
        return services.size();
    }

    class HomeViewHolder extends RecyclerView.ViewHolder implements OnClickListener {

        private ImageView serviceImage;
        private TextView  serviceName;
        OnHomeItemClickListener listener;
        public HomeViewHolder(@NonNull View itemView, OnHomeItemClickListener listener) {
            super(itemView);

            serviceImage = itemView.findViewById(R.id.serviceimage);
            serviceName = itemView.findViewById(R.id.servicename);
            this.listener = listener;
            itemView.setOnClickListener(this);

        }

        @Override
        public void onClick(View v) {
            listener.onHomeItemClick(v, getAdapterPosition());
        }
    }
}
