package com.gwazasoftwares.fisda.models;

public class ChurchService {
    private int holderImage;
    private String serverImage;
    private String name;

    public ChurchService() {
    }

    public ChurchService(int holderImage, String name) {
        this.holderImage = holderImage;
        this.name = name;
    }

    public ChurchService(String serverImage, String name) {
        this.serverImage = serverImage;
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getHolderImage() {
        return holderImage;
    }

    public void setHolderImage(int holderImage) {
        this.holderImage = holderImage;
    }

    public String getServerImage() {
        return serverImage;
    }

    public void setServerImage(String serverImage) {
        this.serverImage = serverImage;
    }
}
