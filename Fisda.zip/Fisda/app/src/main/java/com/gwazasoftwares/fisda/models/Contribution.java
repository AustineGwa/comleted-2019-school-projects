package com.gwazasoftwares.fisda.models;

public class Contribution {
    private String type;
    private String target;
    private int amount;

    public Contribution() {
    }

    public Contribution(String type, String target, int amount) {
        this.type = type;
        this.target = target;
        this.amount = amount;
    }

    public Contribution(String type, int amount) {
        this.type = type;
        this.amount = amount;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getTarget() {
        return target;
    }

    public void setTarget(String target) {
        this.target = target;
    }

    public int getAmount() {
        return amount;
    }

    public void setAmount(int amount) {
        this.amount = amount;
    }
}
