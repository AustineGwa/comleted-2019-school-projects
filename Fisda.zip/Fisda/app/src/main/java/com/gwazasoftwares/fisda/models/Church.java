package com.gwazasoftwares.fisda.models;

import java.util.List;

public class Church {
    private String email;
    private String name;
    private List<Group> groups;
    private List<Department> departments;
    private List<ChurchMember> members;

    public Church() {
    }

    public Church(String email, String name, List<Group> groups, List<Department> departments, List<ChurchMember> members) {
        this.email = email;
        this.name = name;
        this.groups = groups;
        this.departments = departments;
        this.members = members;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public List<Group> getGroups() {
        return groups;
    }

    public void setGroups(List<Group> groups) {
        this.groups = groups;
    }

    public List<Department> getDepartments() {
        return departments;
    }

    public void setDepartments(List<Department> departments) {
        this.departments = departments;
    }

    public List<ChurchMember> getMembers() {
        return members;
    }

    public void setMembers(List<ChurchMember> members) {
        this.members = members;
    }
}
