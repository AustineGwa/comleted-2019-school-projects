package com.gwazasoftwares.fisda;


import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v4.app.Fragment;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;


/**
 * A simple {@link Fragment} subclass.
 */
public class LoginFrag extends Fragment {

    EditText email, password;
    Button login, reset;
    ProgressDialog progressDialog;
    FirebaseAuth mAuth;

    public LoginFrag() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
       View view = inflater.inflate(R.layout.fragment_login, container, false);

        email = view.findViewById(R.id.edemail);
        password = view.findViewById(R.id.adpass);
        login = view.findViewById(R.id.btlogin);
        reset = view.findViewById(R.id.btreset);
        progressDialog = new ProgressDialog(getActivity());
        progressDialog.setMessage("validating user");
        progressDialog.setCanceledOnTouchOutside(false);
        mAuth = FirebaseAuth.getInstance();


       return view;
    }

    @Override
    public void onStart() {
        super.onStart();

        reset.setOnClickListener(new Button.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getActivity(), Reset.class));
            }
        });

        login.setOnClickListener(new Button.OnClickListener() {
            @Override
            public void onClick(View v) {

                String userEmail= email.getText().toString();
                String userPassword = password.getText().toString();

                if(TextUtils.isEmpty(userEmail) && TextUtils.isEmpty(userPassword)){
                    Toast.makeText(getActivity(),"Please enter a valid email and password", Toast.LENGTH_SHORT).show();
                }else{
                    progressDialog.show();
                    login(userEmail, userPassword);
                }

            }
        });


    }

    private void login(String userEmail, String userPassword) {
        mAuth.signInWithEmailAndPassword(userEmail, userPassword)
                .addOnCompleteListener(getActivity(), new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful()) {
                            startActivity(new Intent(getActivity(), Home.class));
                            getActivity().finish();

                        } else {
                            // If sign in fails, display a message to the user.
                            progressDialog.dismiss();
                            Toast.makeText(getActivity(), "Authentication failed. " + task.getException().getMessage(), Toast.LENGTH_LONG).show();

                        }
                    }
                });
         }
}
