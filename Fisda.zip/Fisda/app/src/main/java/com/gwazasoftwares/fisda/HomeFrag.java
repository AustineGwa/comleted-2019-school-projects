package com.gwazasoftwares.fisda;


import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import com.gwazasoftwares.fisda.adapters.HomeAdapter;
import com.gwazasoftwares.fisda.interfaces.OnHomeItemClickListener;
import com.gwazasoftwares.fisda.models.ChurchService;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;


/**
 * A simple {@link Fragment} subclass.
 */
public class HomeFrag extends Fragment {

    RecyclerView recyclerView;
    RecyclerView.Adapter adapter;
    RecyclerView.LayoutManager layoutManager;
    List<ChurchService> services;

    public HomeFrag() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
       View view = inflater.inflate(R.layout.fragment_home, container, false);
       recyclerView = view.findViewById(R.id.homerecyclerview);
       recyclerView.setHasFixedSize(true);
       layoutManager = new GridLayoutManager(getActivity(),3);
       recyclerView.setLayoutManager(layoutManager);
       services = new ArrayList<>();

       return view;
    }

    @Override
    public void onStart() {
        super.onStart();
        ChurchService departments = new ChurchService(R.drawable.department, "Departments");
        ChurchService members = new ChurchService(R.drawable.group, "Members");
        ChurchService funds = new ChurchService(R.drawable.fund, "Funds");
        ChurchService group = new ChurchService(R.drawable.group, "Groups");
        ChurchService expenses = new ChurchService(R.drawable.expense, "Expenses");
        ChurchService Reports = new ChurchService(R.drawable.reports, "Reports");

        OnHomeItemClickListener listener = new OnHomeItemClickListener() {
            @Override
            public void onHomeItemClick(View view, int position) {
                if(position == 1) {

                    }else if(position == 2 ){
                    startActivity(new Intent(getActivity(), Payment.class));
                }else {
                    Toast.makeText(getActivity(), "you have clicked- position :  " + position + "  View : " + view.getId(), Toast.LENGTH_SHORT).show();
                }
            }
        };

        services.clear();
        services.addAll(Arrays.asList(departments,members,funds,group,expenses,Reports));
        adapter = new HomeAdapter(services, listener);
        recyclerView.setAdapter(adapter);


    }
}
